# This file is added into .gitignore

SECRET_KEY = 'l0q=@1rwhu(qq$9lklc=j4d&_5=6hwtj6*-er$0h0bhu46_l=s'
